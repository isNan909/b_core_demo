<template>
  <div id="app">
    <Appheader></Appheader>
    <Content></Content>
  </div>
</template>

<script>
import Content from './components/Dashboard/Content.vue'
import Appheader from './components/UIComponents/Appheader.vue'
export default {
  name: 'App',
  components:{
  'Content': Content,
  'Appheader': Appheader
},
}
</script>

<style lang='sass'>
  @import ./sass/global
</style>
