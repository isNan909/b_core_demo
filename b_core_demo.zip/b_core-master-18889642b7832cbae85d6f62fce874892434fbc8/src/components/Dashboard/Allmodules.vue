<template>
  <div class="b-modules">
    <h1 class="title1">All Modules</h1>
  </div>
</template>

<script>
export default {
  name: 'Modules'
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
