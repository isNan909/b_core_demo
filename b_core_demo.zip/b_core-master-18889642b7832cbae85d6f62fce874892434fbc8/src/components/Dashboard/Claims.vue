<template>
  <div class="b-claims">
    <h1 class="title1">Claims</h1>
  </div>
</template>

<script>
export default {
  name: 'Claims'
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
