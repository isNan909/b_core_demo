<template>
  <div class="b-contact">
    <h1 class="title1">Contact Field</h1>
  </div>
</template>

<script>
export default {
  name: 'Contacts'
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
