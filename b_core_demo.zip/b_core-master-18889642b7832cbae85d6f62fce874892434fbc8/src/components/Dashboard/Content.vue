<template>
  <div class="hero-body">
    <div class="container">
        <router-view/>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Content',
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="sass">

</style>
