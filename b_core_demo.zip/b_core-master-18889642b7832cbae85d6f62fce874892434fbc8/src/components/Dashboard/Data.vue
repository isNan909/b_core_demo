<template>
  <div class="b-data">
    <h1 class="title1">Data</h1>
  </div>
</template>

<script>
export default {
  name: 'Data'
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
