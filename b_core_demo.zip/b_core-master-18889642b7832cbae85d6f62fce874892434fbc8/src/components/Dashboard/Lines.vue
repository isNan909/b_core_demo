<template>
  <div class="page">
    <h1 class="title1">Commercial Property - Add Field</h1>
    <div class="wrapper">
      <div class="columns">
        <div class="column is-3">
          <field-type></field-type>
        </div>
        <div class="column gutter">
          <div class="columns parallel">
            <div class="column is-8">
              <field-detail></field-detail>
            </div>
            <div class="column">
              <field-group></field-group>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="field-body line_footer">
      <div class="field">
        <a href="" class="button is-primary">Save Changes</a>
      </div>
      <div class="field is-grouped is-grouped-right">
        <a href="" class="button">Cancel Changes</a>
        <a href="" class="button is-danger">Delete Input</a>
      </div>
    </div>
  </div>
</template>

<script>
import FieldType from '../LayoutLine/FieldType'
import FieldDetail from '../LayoutLine/FieldDetail'
import FieldGroup from '../LayoutLine/FieldGroup'
export default {
  name: 'Lines',
  components: {
    'field-type': FieldType,
    'field-detail': FieldDetail,
    'field-group': FieldGroup
  }
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style lang="sass">

</style>
