<template>
  <div class="b-policies">
    <h1 class="title1">Policies</h1>
  </div>
</template>

<script>
export default {
  name: 'Policies'
}
</script>

<!-- We Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
</style>
