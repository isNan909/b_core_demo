<template>
  <a class="dropdown navbar-item"
    :class="{'is-active': isActive}"
    @click="toggleDropDown"
    v-click-outside="closeDropDown">
    <slot name="title">
      <a class="navbar-link">
        {{title}}
      </a>
      <b class="caret"></b>
    </slot>
    <div class="dropdown-menu navbar-dropdown is-boxed" @mouseleave="mouseLeave">
      <slot></slot>
    </div>
  </a>
</template>
<script>
  export default {
    name: 'drop-down',
    props: {
      title: String,
      tag: {
        type: String,
      }
    },
    data () {
      return {
        isActive: false
      }
    },
    methods: {
      toggleDropDown () {
        this.isActive = !this.isActive
      },
      mouseLeave () {
        this.isActive = false
        this.$emit('change', this.isActive)
      },
      closeDropDown () {
        this.isActive = false
        this.$emit('change', this.isActive)
      }
    }
  }
</script>

<style scoped lang="sass">
  .dropdown .dropdown-toggle
    cursor: pointer
</style>
