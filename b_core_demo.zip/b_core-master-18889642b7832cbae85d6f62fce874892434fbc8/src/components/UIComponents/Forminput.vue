<template>
  <div class="field">
    <label class="label">
      <slot name="label">
        <label v-if="label" class="control-label">
        {{label}}
      </label>
      </slot>
    </label>
    <div class="control">
      <input
      :value="value"
      @input="$emit('input',$event.target.value)"
      v-bind="$attrs"
      class="input">
    </div>
    <slot></slot>
  </div>
</template>

<script>
  export default {
    inheritAttrs: false,
    name: 'fg-input',
    props: {
      label: String,
      value: [String, Number]
    },
  }
</script>
<style>

</style>
