<template>
  <div class="field">
    <div class="border-box white-bg auto">
      <span class="icon">
        <slot name="icon"></slot>
      </span>
      <span class="title5 title-bold">{{title}}</span>
      <slot>
      </slot>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'sidebar-box',
    props: {
      title: String,
    },
  }
</script>
<style>

</style>
