<template>
  <div class="parallel gutter-tp">
    <h4 class="title4 title-bold">Field Details</h4>
    <div class="field-body field-gap">
      <fg-input type="text"
        label="Display Label"
        v-model="user.displayLabel">
        <p class="font-sm">For display purpose, spaces allowed</p>
      </fg-input>
      <fg-input type="text"
        label="Reference Name"
        v-model="user.referenceName">
        <p class="font-sm">For display purpose, spaces allowed</p>
      </fg-input>
    </div>
    <div class="field-body field-gap">
      <div class="column is-half-desktop">
        <fg-input type="text"
          label="Default Label"
          v-model="user.defaultValue">
        </fg-input>
        <fg-input type="text"
          label="Custom Validation"
          v-model="user.customValidation">
          <p class="font-sm">Any regex pattern For Display purpose, spaces allowed</p>
        </fg-input>
      </div>
    </div>
    <div class="tag-block">
      <h5 class="title5 title-bold">Tags</h5>
      <div class="columns">
        <div class="column">
          <span class="tags title-bold">Tag Group</span>
          <button class="button is-default">Vinmaster</button>
          <button class="button is-default">ISO</button>
          <button class="button is-default">Tag3</button>
        </div>
        <div class="column">
          <span class="tags title-bold">Tags</span>
          <p style="font-style:italic">Select a tag group</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'fieldDetail',
  data () {
    return {
      user: {
        displayLabel: '',
        defaultValue: '',
        customValidation: '',
        referenceName: '',
      }
    }
  },
}
</script>

<style lang="sass">
@import ~bulma/sass/utilities/_all
@import ~bulma/sass/elements/tag
@import ~bulma/sass/elements/button
</style>
