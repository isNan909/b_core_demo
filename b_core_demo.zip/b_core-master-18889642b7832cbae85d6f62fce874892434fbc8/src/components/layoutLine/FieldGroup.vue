<template>
  <div class="parallel level-gap">
    <div class="border-box light-bg">
      <h5 class="title5 title-bold">Field Groups</h5>
      <p class="font-sm">Choose a group for this Input</p>
      <div class="border-box auto">
        <h6 class="title7 title-bold">Rental Vehicle</h6>
        <p class="font-sm">7 other Inputs</p>
      </div>
      <div class="position-bottom">
        <div class="column">
          <button class="button is-full">Add A New Groups</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'fieldGroup'
}
</script>

<style>
</style>
