import DropDown from './components/UIComponents/Dropdown'
import fgInput from './components/UIComponents/Forminput'
import SidebarBox from './components/UIComponents/Sidebarbox'

/**
 * Register global components here and use them as a plugin in your main Vue instance
 */

const GlobalComponents = {
    install(Vue) {
        Vue.component('drop-down', DropDown)
        Vue.component('fg-input', fgInput)
        Vue.component('sidebar-box', SidebarBox)
    }
}

export default GlobalComponents
