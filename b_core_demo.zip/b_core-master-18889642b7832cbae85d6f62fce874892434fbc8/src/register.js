/**
 * This is the GlobalComponents and GlobalDirectives are registered
 */

// A plugin where we could register global components used across the app
import GlobalComponents from './globalComponents'

// A plugin where we could register global directives
import GlobalDirectives from './globalDirectives'


export default {
  install (Vue) {
    Vue.use(GlobalComponents)
    Vue.use(GlobalDirectives)
  }
}
