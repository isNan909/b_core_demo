import Vue from 'vue'
import Router from 'vue-router'
import Policies from '@/components/Dashboard/Policies'
import Claims from '@/components/Dashboard/Claims'
import Contacts from '@/components/Dashboard/Contacts'
import Data from '@/components/Dashboard/Data'
import Lines from '@/components/Dashboard/Lines'
import Allmodules from '@/components/Dashboard/Allmodules'

Vue.use(Router)

export default new Router({
    routes: [{
            path: '/Policies',
            name: 'Policies',
            component: Policies
        },
        {
            path: '/Claims',
            name: 'Claims',
            component: Claims
        },
        {
            path: '/Contacts',
            name: 'Contacts',
            component: Contacts
        },
        {
            path: '/Data',
            name: 'Data',
            component: Data
        },
        {
            path: '/Lines',
            name: 'Lines',
            component: Lines
        },
        {
            path: '/',
            redirect: '/Lines',
            component: Lines
        },
        {
            path: '/Allmodules',
            name: 'Allmodules',
            component: Allmodules
        },
    ]
})
